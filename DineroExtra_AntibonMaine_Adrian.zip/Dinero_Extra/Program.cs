﻿using System.Text;
using System.Text.RegularExpressions;
public class Program
{

    public static void Main(string[] args)
    {
        string nombre = "";
        while (true)
        {
            Console.WriteLine("Introduzca su nombre");
            nombre = Console.ReadLine();
            if (!string.IsNullOrWhiteSpace(nombre) && nombre != "0")
            {
                break;
            }
            Console.WriteLine("Nombre no válido");
        }
        int edad = 0;
        while (true)
        {
            Console.WriteLine("Introduzca su edad");
            string s = Console.ReadLine();
            if (int.TryParse(s, out edad)) break;
            Console.WriteLine("Edad no válida");
        }
        Usuario u = new Usuario(nombre, edad);
        while (true)
        {
            Console.Write("DNI (8 dígitos y letra): ");
            string dni = Console.ReadLine();
            if (u.setDNI(dni)) break;
            Console.WriteLine("DNI no válido");

        }
        Cuenta cuenta = new Cuenta(u);
        Wishlist wishlist = new Wishlist("Deseos", u, cuenta);

        Menu menu = new Menu(cuenta, wishlist);
        menu.Mostrar();

    }
}