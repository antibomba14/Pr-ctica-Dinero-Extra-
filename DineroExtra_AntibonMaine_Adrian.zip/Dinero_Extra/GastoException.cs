﻿using System;

public class  GastoException : Exception
{
    public GastoException() : base("Saldo insuficiente, introduce una cantidad correcta.") { }
}