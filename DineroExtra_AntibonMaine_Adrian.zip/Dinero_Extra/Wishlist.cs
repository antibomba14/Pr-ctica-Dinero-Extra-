﻿using System;

public class Wishlist
{
	private string nombre;
	private List<Producto> productos;
	private Usuario usuario;
	private Cuenta cuenta;

    public Wishlist(string nombre, Usuario usuario, Cuenta cuenta)
	{
		this.nombre = nombre;
		this.usuario = usuario;
		this.cuenta = cuenta;
		this.productos = new List<Producto>();
    }
    //Getters and Setters
    public string getNombre()
	{
		return nombre;
    }
	public string setNombre()
    {
		return nombre;
    }
	public void addProducto(Producto p)
	{
		productos.Add(p);
    }
	public List<Producto> getProductos()
	{
		return productos;
    }
	public Usuario getUsuario()
	{
		return usuario;
    }
	public void setUsuario(Usuario u)
	{
		this.usuario = u;
	}

	// Usado para reservar GastoBasico del mes actual como ahorro del mes siguiente.
	public List<Producto> getProductoParaComprar()
	{
		List<Producto> comprables = new List<Producto>();

		//saldo disponible = saldo actual - suma de básicos del mes actual
		double saldoDisponible = cuenta.getSaldo();
		Console.WriteLine("DEBUG saldoDisponible inicial " + saldoDisponible);

		// Productos que se pueden comprar con el saldo disponible
		for (int i = 0; i < productos.Count; i++)
		{
			Producto p = productos[i];
			Console.WriteLine("DEBUG Producto " + p.getNombre() + "precio " + p.getPrecio() + " saldoDisponible " + saldoDisponible);
			if (p.getPrecio() <= saldoDisponible)
			{
				comprables.Add(p);
			}
		}
		return comprables;
	}

		public override string ToString()
	{
		return "Wishlist: " + nombre + " (" + productos.Count + " productos) de " + usuario.ToString();
    }
    }
