﻿using System;
using System.Data;
using System.Security.Cryptography.X509Certificates;

public class  Cuenta : GastoException 
{
    public double saldo;
    public Usuario usuario;
    public List<Gasto> gastos;
    public List<Ingreso> ingresos;

    public Cuenta (Usuario usuario)
    {
        this.usuario = usuario;
        this.saldo = 0.0;
        this.gastos = new List<Gasto>();
        this.ingresos = new List<Ingreso>();
    }

    public double getSaldo()
    {
        return this.saldo;
    }

    public void setSaldo(double s)
    {
        this.saldo = s;
    }

    public Usuario getUsuario()
    {
        return this.usuario;
    }
    public void setUsuario(Usuario u)
    {
        this.usuario = u;
    }

    public double addIngresos(double cantidad, string descripcion,DateTime fecha)
    {
        Ingreso i = new Ingreso(cantidad, descripcion);
        i.setFecha(fecha);
        ingresos.Add(i);
        saldo += cantidad;
        return saldo;
    }

    public double addGastoBasico(double cantidad, string descripcion, DateTime fecha)
    {
        if (saldo < cantidad) throw new GastoException();
        {
            GastoBasico g = new GastoBasico(cantidad, descripcion, fecha);
            gastos.Add(g);
            saldo -= cantidad;
            return saldo;
        }
    }

    public double addGastoExtra(double cantidad, string descripcion, bool prescindible, DateTime fecha)
    {
        if (saldo < cantidad) throw new GastoException();
        {
            GastoExtra g = new GastoExtra(cantidad, descripcion, fecha, prescindible);
            gastos.Add(g);
            saldo -= cantidad;
            return saldo;
        }
    }
    
    public List<Ingreso> getIngresos() { return ingresos; }
    public List<Gasto> getGastos() { return gastos; }

    public List<Gasto> getGastosBasicos(bool esteMes)
    {
       List<Gasto> gasB = new List<Gasto>();
       DateTime now = DateTime.Now;

       foreach (Gasto g in gastos)
        {
            if (g is GastoBasico)
        {
            GastoBasico gb = (GastoBasico)g;
            if (!esteMes || (gb.getFecha().Month == now.Month && gb.getFecha().Year == now.Year))
            {
                gasB.Add(gb);
            }
          }
        }
         return gasB;
    }

    public List<Gasto> getGastosExtras(bool esteMes)
    {
        List<Gasto> gasE = new List<Gasto>();
        DateTime now = DateTime.Now;

        foreach (Gasto g in gastos)
        {
            if (g is GastoExtra)
            {
                GastoExtra ge = (GastoExtra)g;
                if (!esteMes || (ge.getFecha().Month == now.Month && ge.getFecha().Year == now.Year))
                {
                    gasE.Add(ge);
                }
            }
        }
        return gasE;
    }

    // Ahorro y gastos imprescindibles 

    public double getAhorro(DateTime fechaInicio, DateTime fechaFin)
    {
        double totalIngresos = 0.0;
        foreach (Ingreso i in ingresos)
        {
            DateTime f = i.getFecha();
            if (f >= fechaInicio && f <= fechaFin)
            {
                totalIngresos += i.getCantidad();
            }
        }

        double totalGastos = 0.0;
        foreach (Gasto g in gastos)
        {
            DateTime f = DateTime.MinValue;
            if (g is GastoBasico)
            {
                f = ((GastoBasico)g).getFecha();
            }
            else if (g is GastoExtra)
            {
                f = ((GastoExtra)g).getFecha();
            }

            if (f >= fechaInicio && f <= fechaFin)
            {
                totalGastos += g.getCantidad();
            }
        }
        return totalIngresos - totalGastos;
    }
    // Básicos + Extra imprescindibles
    public double getGastosImprescindibles(DateTime fechaInicio, DateTime fechaFin)
    {
        double total = 0.0;
        foreach (Gasto g in gastos)
        {
            if (g is GastoBasico)
            {
                GastoBasico gb = (GastoBasico)g;
                DateTime f = gb.getFecha();
                if (f >= fechaInicio && f <= fechaFin)
                {
                    total += gb.getCantidad();
                }
            }
            else if (g is GastoExtra)
            {
                GastoExtra ge = (GastoExtra)g;
                DateTime f = ge.getFecha();
                if (!ge.getPrescindible() && f >= fechaInicio && f <= fechaFin)
                {
                    total += ge.getCantidad();
                }
            }
        }
        return total;
    }

    public override string ToString()
    {
        return usuario.ToString() + "\nSaldo actual: " + saldo + "EUR";
    }

}