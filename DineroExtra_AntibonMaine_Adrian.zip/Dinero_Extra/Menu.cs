﻿using System;
using System.ComponentModel;
using System.Globalization;
using System.Collections.Generic;

public class Menu
{
    private Cuenta cuenta;
    private Wishlist wishlist;

    public Menu(Cuenta cuenta, Wishlist wishlist)
    {
        this.cuenta = cuenta;
        this.wishlist = wishlist;
    }

    public void Mostrar()
    {
        int opcion = -1;
        do
        {
            ImprimirMenu();
            opcion = LeerEntero("Opción: ");
            Console.WriteLine();

            switch (opcion)
            {
                case 1: NuevoGastoBasico(); break;
                case 2: NuevoGastoExtra(); break;
                case 3: NuevoIngreso(); break;
                case 4: MostrarGastos(); break;
                case 5: MostrarIngresos(); break;
                case 6: Console.WriteLine("Saldo: " + cuenta.getSaldo() + " EUR"); break;
                case 7: MostrarAhorroPeriodo(); break;
                case 8: MostrarGastosImprescindibles(); break;
                case 9: MostrarPosiblesAhorrosMesPasado(); break;
                case 10: MostrarWishList(); break;
                case 11: MostrarProductosComprables(); break;
                case 0: break;
                default: Console.WriteLine("Opción incorrecta, seleccione una opción válida por favor."); break;
            }
            Console.WriteLine();
            } while (opcion != 0);
        }

private void ImprimirMenu()
    {
        Console.WriteLine("Realiza una nueva acción");
        Console.WriteLine("1. Introduce un nuevo gasto básico");
        Console.WriteLine("2. Introduce un nuevo gasto extra");
        Console.WriteLine("3. Introduce un nuevo ingreso");
        Console.WriteLine("4. Mostrar gastos");
        Console.WriteLine("5. Mostrar ingresos");
        Console.WriteLine("6. Mostrar saldo");
        Console.WriteLine("7. Mostrar ahorro de un periodo");
        Console.WriteLine("8. Mostrar gastos imprescindibles");
        Console.WriteLine("9. Mostrar posibles ahorros del mes pasado");
        Console.WriteLine("10. Mostrar lista de deseos");
        Console.WriteLine("11. Mostrar productos que se pueden comprar");
        Console.WriteLine("0. Salir");
    }

    private void NuevoGastoBasico()
    {
        string desc = LeerTexto("Descripción: ");
        double cant = LeerDouble("Cantidad: ");
        bool manual = LeerBoolean("¿Introducir fecha manual? (s/n): ");

        DateTime fecha;
        if (manual) fecha = LeerFecha("Fecha (dd/MM/yyyy): ");
        else fecha = DateTime.Now;

        try
        { 
            double s = cuenta.addGastoBasico(cant, desc, fecha);
            Console.WriteLine("Gasto básico añadido. Saldo: " + s.ToString("0.##") + " EUR");
        }
        catch (GastoException ex)
        {
            Console.WriteLine(ex.Message);
        }
    }

    private void NuevoGastoExtra()
    {
        string desc = LeerTexto("Descripción: ");
        double cant = LeerDouble("Cantidad: ");
        bool presc = LeerBoolean("¿Es prescindible? (s/n): ");
        bool manual = LeerBoolean("¿Introducir fecha manual? (s/n): ");
        
        DateTime fecha;
        if (manual) fecha = LeerFecha("Fecha (dd/MM/yyyy): ");
        else fecha = DateTime.Now;
         try
        { 
            double s = cuenta.addGastoExtra(cant, desc, presc, fecha);
            Console.WriteLine("Gasto extra añadido. Saldo: " + s.ToString("0.##") + " EUR");
        }
        catch (GastoException ex)
        {
            Console.WriteLine(ex.Message);
        }
    }

    private void NuevoIngreso()
    {
        string desc = LeerTexto("Descripción: ");
        double cant = LeerDouble("Cantidad: ");
        bool manual = LeerBoolean("¿Introducir fecha manual? (s/n): ");

        DateTime fecha;
        if (manual) fecha = LeerFecha("Fecha (dd/MM/yyyy): ");
        else fecha = DateTime.Now;

        double s = cuenta.addIngresos(cant, desc, fecha);
        Console.WriteLine("Ingreso añadido. Saldo: " + s.ToString("0.##") + " EUR");
    }

    private void MostrarGastos()
    {
        Console.WriteLine("1. Totales  2. Básicos  3. Extras");
        int t = LeerEntero("Seleccione tipo de gasto: ");

        List<Gasto> lista;
        if (t == 1) lista = cuenta.getGastos();
        else if (t == 2) lista = cuenta.getGastosBasicos(false);
        else if (t == 3) lista = cuenta.getGastosExtras(false);
        else
        {
            Console.WriteLine("Opción incorrecta.");
            return;
        }
        if (lista.Count == 0)
        {
            Console.WriteLine("No hay gastos que mostrar.");
            return;
        }
        for (int i = 0; i < lista.Count; i++)
            Console.WriteLine("- " + lista[i].ToString());
    }
    private void MostrarIngresos()
    {
        List<Ingreso> lista = cuenta.getIngresos();
        if (lista.Count == 0)
        {
            Console.WriteLine("No hay ingresos que mostrar.");
            return;
        }
        for (int i = 0; i < lista.Count; i++)
            Console.WriteLine("- " + lista[i].ToString());
    }
    private void MostrarAhorroPeriodo()
    {
        DateTime ini = LeerFecha("Fecha inicio (dd/mm/aaaa): ");
        DateTime fin = LeerFecha("Fecha fin (dd/mm/aaaa): ");
        double ahorro = cuenta.getAhorro(ini, fin);
        Console.WriteLine("Ahorro del período: " + ahorro + "EUR");
    }
    private void MostrarGastosImprescindibles()
    {
        DateTime ini = LeerFecha("Fecha inicio (dd/mm/aaaa): ");
        DateTime fin = LeerFecha("Fecha fin (dd/mm/aaaa): ");
        double imp = cuenta.getGastosImprescindibles(ini, fin);
        Console.WriteLine("Gastos imprescindibles del período: " + imp + " EUR");
    }
    private void MostrarPosiblesAhorrosMesPasado()
    {
        DateTime now = DateTime.Now;
        DateTime ini = new DateTime(now.Year, now.Month, 1).AddMonths(-1);
        DateTime fin = new DateTime(now.Year, now.Month, 1).AddTicks(-1); // fin del mes pasado



        List<Gasto> extras = cuenta.getGastosExtras(false);


        double total = 0.0;

        for (int i = 0; i < extras.Count; i++)
        {
            if (extras[i] is GastoExtra)
            {
                GastoExtra ge = (GastoExtra)extras[i];
                DateTime f = ge.getFecha();
                bool enMes = (f >= ini && f <= fin);
                bool presc = ge.getPrescindible();

                if (presc && enMes)
                {
                    total += ge.getCantidad();
                }
            }
        }

        Console.WriteLine("Posibles ahorros del mes pasado: " + total.ToString("0.##") + " EUR");
    }
    private void MostrarWishList()
    {
        int op = -1;
        do
        {
            Console.WriteLine("Wishlist: " + wishlist.getNombre());
            List<Producto> ps = wishlist.getProductos();
            if (ps.Count == 0) Console.WriteLine("Sin productos.");
            else
            {
                for (int i = 0; i < ps.Count; i++)
                    Console.WriteLine((i + 1) + "- " + ps[i].ToString());
            }
            Console.WriteLine();
            Console.WriteLine("1. Añadir producto");
            Console.WriteLine("2. Eliminar producto");
            Console.WriteLine("0. Volver");
            op = LeerEntero("Opción: ");
            Console.WriteLine();
            
            if (op == 1)
            {
                string nombre = LeerTexto("Nombre del producto: ");
                double precio = LeerDouble("Precio del producto: ");
                string enlace = LeerTexto("Enlace del producto: ");
                wishlist.addProducto(new Producto(nombre, precio, enlace));
                Console.WriteLine("Producto añadido.");
            }
            else if (op == 2)
            {
                if (ps.Count == 0) { Console.WriteLine("No hay productos para eliminar."); continue; }
                int idx  = LeerEntero("Número de producto a eliminar: ") - 1;
                if (idx >= 0 && idx < ps.Count)
                {
                    ps.RemoveAt(idx);
                    Console.WriteLine("Producto eliminado.");
                }
                else
                {
                    Console.WriteLine("Índice inválido");
                }
                Console.WriteLine();
            }
            } while (op != 0);
    }
    private void MostrarProductosComprables()
    {
        List<Producto> comprables = wishlist.getProductoParaComprar();
        if (comprables.Count == 0)
        {
            Console.WriteLine("No hay productos que se puedan comprar.");
            return;
        }
        Console.WriteLine("Puedes comprar ahora.");
        for (int i = 0; i < comprables.Count; i++)
            Console.WriteLine("- " + comprables[i].ToString());
    }
    private string LeerTexto(string msg)
    {
        Console.Write(msg);
        string s = Console.ReadLine();
        if ( s == null) return "";
        return s.Trim();
    }
    private int LeerEntero(string msg)
    {
        while (true)
        {
            Console.Write(msg);
            string s = Console.ReadLine();
            int v;
            if (int.TryParse(s, out v))
                return v;
            Console.WriteLine("Número inválido.");
        }
    }

    private double LeerDouble(string msg)
    {
        while (true)
        {
            Console.Write(msg);
            string s = Console.ReadLine();
            double v;
            if (double.TryParse(s, out v))
                return v;
            Console.WriteLine("Cantidad inválido.");
        }
    }

    private bool LeerBoolean(string msg)
    {
        while (true)
        {
            Console.Write(msg);
            string s = Console.ReadLine();
            s = (s ?? "").Trim().ToLowerInvariant();
            if (s == "s" || s == "si" || s == "sí") return true;
            if (s == "n" || s == "no") return false;
            Console.WriteLine("Responde s/n.");
        }
    }

    private DateTime LeerFecha(string msg)
    {
        while (true)
        {
            Console.Write(msg);
            string s = Console.ReadLine();
            DateTime f;
            // Convierte el texto del usuario en la consola a un objeto DateTime.
            if (DateTime.TryParseExact(s, "dd/MM/yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out f))
                return f;
            Console.WriteLine("Fecha inválida. Usa dd/MM/yyyy");
        }
    }
}
