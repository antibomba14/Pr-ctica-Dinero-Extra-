﻿using System;

public class GastoExtra : Gasto
{
    private DateTime fecha;
    private bool prescindible;

    public GastoExtra(double gasto, string descripcion, DateTime fecha, bool prescindible)
        : base(gasto, descripcion)
    {
        this.fecha = fecha;
        this.prescindible = prescindible; // ahora asigna el parámetro correcto
    }

    public DateTime getFecha() { return fecha; }
    public void setFecha(DateTime f) { fecha = f; }

    public bool getPrescindible() { return prescindible; }
    public void setPrescindible(bool p) { prescindible = p; }

    public override string ToString()
    {
        string estado = prescindible ? "Prescindible" : "Imprescindible";
        return "Gasto Extra: " + cantidad + " EUR - " + descripcion + " - "
             + fecha.ToString("dd/MM/yyyy") + " - " + estado;
    }
}

