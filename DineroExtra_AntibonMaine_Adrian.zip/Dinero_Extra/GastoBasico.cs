﻿using System;
using System.Data;

public class GastoBasico : Gasto
{
    private DateTime fecha;

    public GastoBasico(double gasto, string descripcion, DateTime fecha) : base(gasto,descripcion)
    {
        this.fecha = fecha;
    }

    public DateTime getFecha() 
    {        
        return fecha;
    }
    public void setFecha(DateTime f) 
    {        
        fecha = f;
    }
    

    public override string ToString() 
    {
        return "Gasto Básico: " + cantidad + " - " + descripcion + " - " + fecha.ToString("dd/MM/yyyy");
    }
}
