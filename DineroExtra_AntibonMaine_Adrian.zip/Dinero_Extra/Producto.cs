﻿using System;

public class Producto
{
	private string nombre;
	private double precio;
	private string enlace;

    public Producto(string nombre, double precio, string enlace)
	{
		this.nombre = nombre;
		this.precio = precio;
		this.enlace = enlace;
    }

	public void setNombre(string n)
	{
		this.nombre = n;
    }
	public string getNombre() {       
		return nombre;
    }
	public void setPrecio(double p)
    {
		this.precio = p;
    }
	public double getPrecio() {       
		return precio;
    }
	public void setEnlace(string e)
    {
		this.enlace = e;
    }
    public string getEnlace() {       
		return enlace;
    }

	public override string ToString()
	{
		return "Producto: " + nombre + " - " + precio + "EUR, - " + enlace;
    }
}
