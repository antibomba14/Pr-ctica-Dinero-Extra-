﻿public abstract class Gasto : Dinero
{
       public Gasto(double gasto, string descripcion) : base(gasto, descripcion) { }

}