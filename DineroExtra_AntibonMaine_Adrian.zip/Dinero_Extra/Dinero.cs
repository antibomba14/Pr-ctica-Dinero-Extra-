﻿using System;

public abstract class Dinero
{

    protected double cantidad;
    protected string descripcion;

    public Dinero(double gasto, string descripcion) 
    { 
        this.cantidad = gasto;
        this.descripcion = descripcion;
    }
    public double getCantidad()
    {
        return cantidad;
    }
    public string getDescripcion()
    {
        return descripcion;
    }
    public abstract override string ToString();

}