﻿public class Ingreso : Dinero 
{
    private DateTime fecha;
    public Ingreso(double ingreso, string descripcion) : base(ingreso, descripcion){}

    public DateTime getFecha()
    {
        return fecha;
    }
    public void setFecha(DateTime f)
    {
        fecha = f;
    }
    public override string ToString() 
    {
        return "Ingreso: " + cantidad.ToString("0.##") + "EUR - " + descripcion + " - " + fecha.ToString("dd/MM/yyyy");
    }
}