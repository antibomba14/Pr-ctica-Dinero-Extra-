﻿using System;
using System.Text.RegularExpressions;


public class Usuario
{
	public string nombre;
	public int edad;
	public string dni;

	public Usuario(string nombre, int edad)
	{
		this.nombre = nombre;
		this.edad = edad;
		this.dni = "";
	}

	public bool setDNI(string DNI)
	{
		System.Text.RegularExpressions.Regex rx = new System.Text.RegularExpressions.Regex(@"^\d{8}[A-Za-z]$");
		if (rx.IsMatch(DNI))
		{
			dni = DNI;
			return true;
		}
		return false;
	}

	public override string ToString()
	{
		return "Usuario: " + nombre + ", Edad: " + edad + ", DNI: " + dni;
    }

}